Logo Commodore 64 by syntonia on Thingiverse: https://www.thingiverse.com/thing:2396696

Summary:
Logo Commodore 64 
