Amiga Logo by syntonia on Thingiverse: https://www.thingiverse.com/thing:2374923

Summary:
Logo Commodore Amiga